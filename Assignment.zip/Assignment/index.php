<?php
// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Retrieve form data
  $title = $_POST['title'];
  $firstName = $_POST['firstName'];
  $lastName = $_POST['lastName'];
  $contactNumber = $_POST['contactNumber'];
  $district = $_POST['district'];

  
			// creat the connection with db
			$connection = mysqli_connect('localhost','root','','erp_system');

     //	the query to execute
			$query =" INSERT INTO `customer` (`id`, `title`, `first_name`, `middle_name`, `last_name`, `contact_no`, `district`) VALUES
      ('$title','$firstName','$lastName ','$contactNumber','$district')" ;

  exit;
}
?>


<html>
   <head>
      <title></title>
          <!-- Include Bootstrap CSS link -->
          <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head><script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
  $(document).ready(function() {
    // Customer Form Validation
    $('#customerForm').submit(function(event) {
      if (!validateCustomerForm()) {
        event.preventDefault();
      }
    });

    function validateCustomerForm() {
      // Add your customer form validation logic here
      // For example, check if fields are not empty, validate contact number format, etc.
      return true; // Return true if the form is valid; otherwise, return false.
    }

    // Item Form Validation
    $('#itemForm').submit(function(event) {
      if (!validateItemForm()) {
        event.preventDefault();
      }
    });

    function validateItemForm() {
      // Add your item form validation logic here
      // For example, check if fields are not empty, validate quantity and price, etc.
      return true; // Return true if the form is valid; otherwise, return false.
    }
  });
</script>



<body>
        <div class="container mt-4">
          <div class="panel panel-primary">
            <div class="panel-heading">
              <h2>Customer Registration Form</h2>
            </div>
            <div class="panel body">
              <form id="customerForm" action="process_customer.php" method="post">
                <div class="row">
                  <div class="col-sm-6">
                      <label for="title" class="form-label">Title</label>
                      <select class="form-select" id="title" name="title" required>
                          <option value="Mr">Mr</option>
                          <option value="Mrs">Mrs</option>
                          <option value="Miss">Miss</option>
                          <option value="Dr">Dr</option>
                        </select>
                  </div>
                </div>
          <div class="row">
            <div class="col-sm-6">
                <label for="firstName" class="form-label">First Name</label>
                <input type="text" class="form-control" id="firstName" name="firstName" required>
            </div> 

            <div class="col-sm-6">
                <label for="lastName" class="form-label">Last Name</label>
                <input type="text" class="form-control" id="lastName" name="lastName" required>
            </div>

           </div>
           <div class="row">
                  <div class="col-sm-6">
                      <label for="contactNumber" class="form-label">Contact Number</label>
                      <input type="tel" class="form-control" id="contactNumber" name="contactNumber" required>
                  </div>
                <div class="col-sm-6">
                      <label for="district" class="form-label">District</label>
                      <input type="text" class="form-control" id="district" name="district" required>
                </div>
           </div><br>
           <?php
           echo '<a href="Untiled-2.php">
          <button type="submit" class="btn btn-primary" > Next </button>
        </a>';
        ?>
        </form>
       </div>
        </div>
 </div>
 </body>
<html>